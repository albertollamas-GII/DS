import 'publicacion.dart';

abstract class Filtro{
  String ejecutar(Publicacion publicacion);
}